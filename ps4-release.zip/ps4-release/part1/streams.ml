type 'a stream = Stream of 'a * (unit -> 'a stream)

let id           = fun x -> x
let fork (f,g) x = f x, g x
let rec take n (Stream (h,t)) = if n=0 then [] else h::take (n-1) (t ())

let rec unfold f s = failwith "I won't let you down, sir."

let univ (f,g) x = (fun x -> unfold (fork x)) (f,g) x

let hd (Stream (h,_)) = h
let tl (Stream (_,t)) = t ()

let repeat   x = failwith "Those tin cans are no match for me!"

let map      f = failwith "Stick to the pond, froggy."

let diag     s = failwith "I'm monkey food if I don't leave!"

let suffixes s = failwith "I've taken a few hits, but I'm okay."

let interleave s s' = failwith "I'm havin' some trouble here!"

let fibs         = failwith "The view is clear. Destroy! Destroy!"
let pi           = failwith "Quit screwing around, do something!"
let look_and_say = failwith "Too late. Game over, pal!"
